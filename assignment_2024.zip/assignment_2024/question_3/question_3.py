import pandas as pd
import csv
from datetime import datetime,date

# with open("/home/user/Pictures/assignment/Interview Questions./question_3_input.xlsx",encoding="UTF-16") as excel_file:
#     csv_file=csv.reader(excel_file)
#     for i in csv_file:
#         print(i)

data_dictionary={}
data=pd.read_excel("./Interview Questions..xlsx",sheet_name="Q3",usecols=[0,1],index_col=1)

df=pd.DataFrame(data)

for row in df.iterrows():
    sales=row[0]
    date_object=datetime.strptime(str(row[1]).split(" ")[3].split("\n")[0],"%Y-%m-%d") #split and convert date object
    # month_name=date_object.strftime("%b")

    #creating dictionary same as we want
    month_name=date_object.strftime("%m")

    try:
        if month_name not in data_dictionary[date_object.year]:
            data_dictionary[date_object.year][month_name]=sales
            
        else:
            data_dictionary[date_object.year][month_name]+=sales
    except Exception as e:
        data_dictionary[date_object.year]={month_name:sales}

   
df_new=pd.DataFrame(data_dictionary)

#transpose dictionary to achieve target
transposed_df = df_new.transpose()

#sorting dataframe by month number
sorted_columns = sorted(transposed_df.columns)
sorted_df = transposed_df[sorted_columns]

#rename month number to month name
new_column_name={column:datetime.strptime(column,"%m").strftime("%b") for column in sorted_df.columns}

sorted_df = sorted_df.rename(columns=new_column_name)


sorted_df.to_excel("question_3.xlsx",index_label="Year",sheet_name="Q3")
