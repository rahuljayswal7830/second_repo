from bs4 import BeautifulSoup
import requests
from datetime import datetime
import lxml
import json
import time
import pandas as pd

# while loop working untill it reach last page .if stuck in page ,it return previous page and drop data and start again to adding next page data
page_num=0
total=1
all_collection=[]


while page_num<total:
    # url_path="https://dell.wd1.myworkdayjobs.com/en-US/External?Location_Country=c4f78be1a8f14da0ab49ce1162348a5e"
    url_path="https://dell.wd1.myworkdayjobs.com/wday/cxs/dell/External/jobs"



    json_payload={"appliedFacets":
            {"Location_Country":["c4f78be1a8f14da0ab49ce1162348a5e"]},
           "limit":20,"offset":page_num*20,"searchText":""}
    
   
    print(json_payload)

    responce_obj=requests.post(url_path, json=json_payload)

    time.sleep(3)

    soup = BeautifulSoup(responce_obj.content, "lxml")

    data=json.loads(soup.html.body.p.string)
   

    try:
        if total==1:
            all_job_number=int(data['total'])
            print("all_job_number",all_job_number)
            if not all_job_number%20==0:
                total=(all_job_number//20)+1 #moving to number of pages
            else:
                total=all_job_number//20

        print("total :=",total)
        print("page_num_from: =",page_num)
        
        for job in data["jobPostings"]:
            data_dictionary={}

            data_dictionary.update({"Job Title":job["title"],
                                    "Location":job['locationsText'],
                                    "Req Id":job["bulletFields"][0],
                                    "Job Link":"https://dell.wd1.myworkdayjobs.com/en-US/External"+job["externalPath"] })
                
            
            all_collection.append(data_dictionary)
        page_num+=1
        print("page_num_to: =",page_num)
    except Exception as e:
        #if any error get, page will be repeat again
        print(e)
        page_num-=1
        total=total
        all_collection=all_collection[:page_num*20+1] #data cleaning ,not making repeatitve
        continue



df=pd.DataFrame(all_collection)
df.to_excel("questions_1.xlsx",index=False, sheet_name='Sheet1') # please first column in formatted cell in text

print("Completed")
#********************Note*********************
# please first column in formatted cell in text


