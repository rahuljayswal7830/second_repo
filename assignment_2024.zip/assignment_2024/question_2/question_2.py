from bs4 import BeautifulSoup
import requests
from datetime import datetime
import lxml
import json
import time
import pandas as pd
from datetime import datetime
import openpyxl

count=0
total=1

all_collection=[]
while count<total:
   
    
    if count==0:
        url_path="https://jobs.bentley.com/search"
    else:
        #for movinf next page
        url_path=f"https://jobs.bentley.com/search?q=&sortColumn=referencedate&sortDirection=desc&searchby=location&d=10&startrow={count}"

    try:
        response=requests.get(url_path)
        soup=BeautifulSoup(response.content,"lxml")

        # print(soup.prettify())
        rows = soup.find_all("tr",class_="data-row")

        page_number=soup.find("span",class_="paginationLabel").text
       

        digit_data=[ int(i)  for i in page_number.split(" ") if i.isdigit()]
       
        total=digit_data[2]
        
        for row in rows:
            data_dictionary={}

            job_name=row.find("span",class_="jobTitle hidden-phone").text

            job_link=row.find("a",class_="jobTitle-link").get("href")
            job_link="https://jobs.bentley.com"+job_link

            job_loc=row.find("span",class_="jobLocation").text.strip()

            job_join_data=row.find("span",class_="jobDate visible-phone").text

            
            job_join_data=datetime.strptime(job_join_data.strip(),"%b %d, %Y") #convert date object
           
            job_join_data=job_join_data.strftime("%d-%b-%y") # convert to string
           
            data_dictionary.update({"Job Title":str(job_name),
                                    "Location":job_loc,
                                    "Job Link":job_link,
                                    "Date":job_join_data})
            all_collection.append(data_dictionary)

 
        count=digit_data[1]
    except Exception as e:
        print(e)

df=pd.DataFrame(all_collection)

df.to_excel("question_2.xlsx", index=False,sheet_name='Sheet1')

print("Completed")
#********************Note*********************
# please first column in formatted cell in text

